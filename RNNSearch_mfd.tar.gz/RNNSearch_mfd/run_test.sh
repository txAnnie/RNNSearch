#THEANO_FLAGS='device=gpu1,floatX=float32' python sampling.py ./data/test_src ./data/test_trg ./data/test_out
THEANO_FLAGS='device=gpu2,floatX=float32' python sampling.py ./data/valid_src ./data/valid_trg ./data/valid_out
