# rnn encoder-decoder for machine translation
import numpy
import theano.tensor as T
import argparse
import logging
import pprint
import time
from stream import DStream, get_devtest_stream
from search import BeamSearch
from sampling import Sampler, BleuValidator
from nmt import EncoderDecoder
import configurations


if __name__=='__main__':
    # Get the arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--proto",  default="get_config_search_gru",
                        help="Prototype config to use for config")
    args = parser.parse_args()

    logger = logging.getLogger(__name__)

    configuration = getattr(configurations, args.proto)()
    logger.info("\nModel options:\n{}".format(pprint.pformat(configuration)))

    src = T.lmatrix()
    src_mask = T.matrix()
    trg = T.lmatrix()
    trg_mask = T.matrix()

    rng = numpy.random.RandomState(1234)

    enc_dec = EncoderDecoder(rng, **configuration)
    enc_dec.build_trainer(src, src_mask, trg, trg_mask)
    enc_dec.build_sampler()

    if configuration['reload']:
        enc_dec.load()

    sample_search = BeamSearch(enc_dec=enc_dec, configuration=configuration,
                               maxlen=configuration['seq_len_src'])
    valid_search = BeamSearch(enc_dec=enc_dec, configuration=configuration,
                              beam_size=configuration['beam_size'],
                              maxlen=3*configuration['seq_len_src'], stochastic=False)

    sampler = Sampler(sample_search, **configuration)
    bleuvalidator = BleuValidator(valid_search, **configuration)

    # train function
    train_fn = enc_dec.train_fn

    # train data
    ds = DStream(**configuration)

    # valid data
    vs = get_devtest_stream(data_type='valid', input_file=None, **configuration)

    # main_loop
    iters = 0
    valid_bleu_best = -1
    epoch_best = -1
    iters_best = -1
    max_epochs = configuration['finish_after']

    for epoch in range(max_epochs):
        for x, x_mask, y, y_mask in ds.get_iterator():
            last_time = time.time()
            tc = train_fn(x.T, x_mask.T, y.T, y_mask.T)
            cur_time = time.time()
            iters += 1
            logger.info('epoch %d \t updates %d train cost %.4f use time %.4f'
                        %(epoch, iters, tc[0], cur_time-last_time))

            if iters % configuration['save_freq'] == 0:
                enc_dec.save()

            if iters % configuration['sample_freq'] == 0:
                sampler.apply(x, y)

            if iters < configuration['val_burn_in']:
                continue

            if (iters <= configuration['val_burn_in_fine'] and iters % configuration['valid_freq'] == 0) \
               or (iters > configuration['val_burn_in_fine'] and iters % configuration['valid_freq_fine'] == 0):
                valid_bleu = bleuvalidator.apply(vs, configuration['valid_out'])
                logger.info('valid_test \t epoch %d \t updates %d valid_bleu %.4f'
                        %(epoch, iters, valid_bleu))
                if valid_bleu > valid_bleu_best:
                    valid_bleu_best = valid_bleu
                    epoch_best = epoch
                    iters_best = iters
                    enc_dec.save(path=configuration['saveto_best'])

    logger.info('final result: epoch %d \t updates %d valid_bleu_best %.4f'
            %(epoch_best, iters_best, valid_bleu_best))

