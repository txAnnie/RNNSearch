THEANO_FLAGS='device=cpu,floatX=float32' python sampling_cpus.py ./data/test_src ./data/test_trg ./data/test_out -p 5
