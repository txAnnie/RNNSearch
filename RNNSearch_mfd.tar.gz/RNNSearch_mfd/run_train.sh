#THEANO_FLAGS='device=gpu1,floatX=float32' python train.py
python train.py
