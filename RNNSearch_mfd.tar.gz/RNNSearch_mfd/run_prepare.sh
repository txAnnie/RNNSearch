python prepare_data.py 1>log.gendict 2>&1
