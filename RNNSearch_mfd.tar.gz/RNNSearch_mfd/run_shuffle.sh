python shuffle.py ./data/ch.txt ./data/en.txt
